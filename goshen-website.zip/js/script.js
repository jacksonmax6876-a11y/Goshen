var WA = "2348035739267";

/* Edit this list with your real properties.
   mode: "sale" or "rent" | kind: "residential", "commercial" or "land" | art: "house", "flat", "warehouse", "land", "shop" */
var LISTINGS = [
  {t:"4-bedroom detached duplex", area:"Magodo", mode:"sale", kind:"residential", art:"house", price:185000000, specs:["4 bed","5 bath","BQ","Gated estate"]},
  {t:"3-bedroom flat", area:"Abule-Egba", mode:"rent", kind:"residential", art:"flat", price:1800000, per:"year", specs:["3 bed","2 bath","Parking","Water"]},
  {t:"Warehouse with office block", area:"Ilupeju", mode:"sale", kind:"commercial", art:"warehouse", price:null, specs:["2,000 sqm","Loading bay","Office block"]},
  {t:"600 sqm residential land", area:"Ibeju-Lekki", mode:"sale", kind:"land", art:"land", price:45000000, specs:["600 sqm","Dry land","Survey ready"]},
  {t:"Mini flat", area:"Agege", mode:"rent", kind:"residential", art:"flat", price:900000, per:"year", specs:["1 bed","1 bath","Tiled"]},
  {t:"Shop and office complex unit", area:"Ikeja", mode:"rent", kind:"commercial", art:"shop", price:3500000, per:"year", specs:["120 sqm","Ground floor","Main road"]}
];

var state = {mode:"all", kind:"all", area:"all"};
var grid = document.getElementById("grid");
var countEl = document.getElementById("count");
var areaSel = document.getElementById("fArea");

function naira(n){ return "\u20A6" + n.toLocaleString("en-NG"); }
function esc(s){ return String(s).replace(/[&<>"]/g, function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];}); }

function art(kind){
  var base = '<svg class="art" viewBox="0 0 320 200" role="img" aria-hidden="true"><rect width="320" height="200" fill="var(--bg-alt)"/><rect y="168" width="320" height="32" fill="var(--line)"/>';
  var shapes = {
    house:'<rect x="80" y="84" width="160" height="84" fill="var(--ink)"/><polygon points="68,88 160,34 252,88" fill="var(--red)"/><rect x="144" y="120" width="32" height="48" fill="var(--bg)"/><rect x="98" y="104" width="26" height="24" fill="var(--bg)"/><rect x="196" y="104" width="26" height="24" fill="var(--bg)"/>',
    flat:'<rect x="96" y="30" width="128" height="138" fill="var(--ink)"/><rect x="96" y="30" width="128" height="14" fill="var(--red)"/><g fill="var(--bg)"><rect x="110" y="58" width="22" height="20"/><rect x="149" y="58" width="22" height="20"/><rect x="188" y="58" width="22" height="20"/><rect x="110" y="94" width="22" height="20"/><rect x="149" y="94" width="22" height="20"/><rect x="188" y="94" width="22" height="20"/><rect x="146" y="132" width="28" height="36"/></g>',
    warehouse:'<polygon points="40,168 40,76 160,44 280,76 280,168" fill="var(--ink)"/><polygon points="34,80 160,38 286,80 286,92 160,52 34,92" fill="var(--red)"/><rect x="64" y="108" width="56" height="60" fill="var(--bg)"/><rect x="132" y="108" width="56" height="60" fill="var(--bg)"/><rect x="200" y="108" width="56" height="60" fill="var(--bg)"/>',
    land:'<polygon points="20,168 90,110 180,140 300,96 300,168" fill="var(--ink)"/><g stroke="var(--red)" stroke-width="4"><line x1="70" y1="168" x2="70" y2="124"/><line x1="130" y1="168" x2="130" y2="132"/><line x1="200" y1="168" x2="200" y2="126"/><line x1="260" y1="168" x2="260" y2="112"/></g><rect x="56" y="50" width="70" height="38" fill="var(--red)"/><rect x="88" y="88" width="6" height="40" fill="var(--ink)"/><text x="91" y="75" text-anchor="middle" font-family="Archivo,Arial" font-weight="800" font-size="16" fill="#fff">SALE</text>',
    shop:'<rect x="50" y="70" width="220" height="98" fill="var(--ink)"/><rect x="40" y="56" width="240" height="22" fill="var(--red)"/><rect x="66" y="96" width="70" height="72" fill="var(--bg)"/><rect x="152" y="96" width="46" height="72" fill="var(--bg)"/><rect x="212" y="96" width="42" height="40" fill="var(--bg)"/>'
  };
  return base + (shapes[kind] || shapes.house) + '</svg>';
}

function render(){
  var list = LISTINGS.filter(function(l){
    return (state.mode==="all" || l.mode===state.mode) &&
           (state.kind==="all" || l.kind===state.kind) &&
           (state.area==="all" || l.area===state.area);
  });
  countEl.textContent = list.length === 1 ? "1 property" : list.length + " properties";
  if(!list.length){
    grid.innerHTML = '<div class="empty" style="grid-column:1/-1"><p>No property matches that search yet. Tell us what you need and we will look for it.</p><a class="btn red" href="#contact">Ask us to find one</a></div>';
    return;
  }
  grid.innerHTML = list.map(function(l){
    var price = l.price ? naira(l.price) + (l.per ? ' <small>/ ' + l.per + '</small>' : '') : 'Price on request';
    var msg = "Hello Goshen, I am interested in the " + l.t + " in " + l.area + " (" + (l.mode==="rent"?"for rent":"for sale") + "). Please send me details.";
    return '<article class="card">' + art(l.art) +
      '<div class="body"><span class="tag ' + l.mode + '">' + (l.mode==="rent"?"For rent":"For sale") + '</span>' +
      '<h3>' + esc(l.t) + '</h3><p class="where">' + esc(l.area) + ', Lagos</p>' +
      '<p class="price">' + price + '</p>' +
      '<ul class="specs">' + l.specs.map(function(s){return '<li>' + esc(s) + '</li>';}).join("") + '</ul>' +
      '<div class="enq"><a class="btn" target="_blank" rel="noopener" href="https://wa.me/' + WA + '?text=' + encodeURIComponent(msg) + '">Enquire on WhatsApp</a></div></div></article>';
  }).join("");
}

/* build area options from listings */
var areas = []; LISTINGS.forEach(function(l){ if(areas.indexOf(l.area)<0) areas.push(l.area); });
areas.sort().forEach(function(a){ var o=document.createElement("option"); o.value=a; o.textContent=a; areaSel.appendChild(o); });

document.querySelectorAll(".seg button").forEach(function(b){
  b.addEventListener("click", function(){
    document.querySelectorAll(".seg button").forEach(function(x){ x.setAttribute("aria-pressed","false"); });
    b.setAttribute("aria-pressed","true");
    state.mode = b.dataset.mode; render();
  });
});
document.getElementById("fType").addEventListener("change", function(e){ state.kind=e.target.value; render(); });
areaSel.addEventListener("change", function(e){ state.area=e.target.value; render(); });
document.getElementById("goBtn").addEventListener("click", function(){
  render(); document.getElementById("listings").scrollIntoView();
});

document.getElementById("enq").addEventListener("submit", function(e){
  e.preventDefault();
  var text = "Hello Goshen, my name is " + document.getElementById("eName").value.trim() +
    " (" + document.getElementById("ePhone").value.trim() + "). I want to: " +
    document.getElementById("eWant").value + "." +
    (document.getElementById("eMsg").value.trim() ? "\n\n" + document.getElementById("eMsg").value.trim() : "");
  window.open("https://wa.me/" + WA + "?text=" + encodeURIComponent(text), "_blank", "noopener");
});

render();
